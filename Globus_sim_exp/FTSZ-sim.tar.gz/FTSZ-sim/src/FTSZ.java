
public class FTSZ {
	public static double[] CR = new double[] {17, 7.7, 4.6, 3.1};
	public static double[] decrease = new double[] {0.107, 0.047, 0.037, 0.036};
	
	//public static double[] CR = new double[] {17};
	//public static double[] decrease = new double[] {0.107};	
	
	public static double[] bandwidth = new double[] {1, 2, 3, 4, 5, 6, 7, 8}; //GB/s
	
	public static double totalIOTime = 800; //seconds
	
	public static double fileSize = (6.0*512*512*512*4); //in bytes
	public static double nbCores = 2048;
	public static double compressionTimeOverhead = 0.25;
	
	public static double diskReadBandwidth = 100*1.0*1024*1024*1024; //bebop: 1.5GB/s 
	public static double diskWriteBandwidth = 100*1.0*1024*1024*1024;//bebop: 1.2GB/s
	
	public static double szCompressionTime = 33; //seconds
	public static double szDecompressionTime = 25;
	
	public static double ftszCompressionTime = 40;
	public static double ftszDecompressionTime = 33;
	
	public static void main(String[] args)
	{
		double baselineDataSize = fileSize*nbCores; //		baselineDataSize = 1TB
		double szCompressionThroughput = baselineDataSize/szCompressionTime;
		double szDecompressionThroughput = baselineDataSize/szDecompressionTime;
		double ftszCompressionThroughput = baselineDataSize/ftszCompressionTime;
		double ftszDecompressionThroughput = baselineDataSize/ftszDecompressionTime;
		
		System.out.println(szCompressionThroughput/1024/1024/1024+" "+szDecompressionThroughput/1024/1024/1024+" "+ftszCompressionThroughput/1024/1024/1024+" "+ftszDecompressionThroughput/1024/1024/1024);
		
		double dataSize = baselineDataSize*1000/6;  //1PB
		
		for(int i = 0;i<bandwidth.length;i++)
		{
			//System.out.println("---------bandwidth = "+bandwidth[i]);
			for(int j = 0;j<CR.length;j++)
			{
				double bw = bandwidth[i]*1024*1024*1024; //GB/s
				double rCR = CR[j]*(1-decrease[j]);
				double rSize = dataSize/CR[j];
				double rSize_ft = dataSize/rCR;
				double compressionTime = dataSize/szCompressionThroughput;
				double compressionTime_ft = dataSize/ftszCompressionThroughput;
				
				double decompressionTime = dataSize/szDecompressionThroughput;
				
				double oriNetworkTransferTime = dataSize/bw;
				double cmpNetWorkTransferTime = rSize/bw;
				double cmpNetWorkTransferTime_ft = rSize_ft/bw;
				double readDataTime = dataSize/diskReadBandwidth;
				double writeOriDataTime = dataSize/diskWriteBandwidth;
				double writeCmpDataTime = rSize/diskWriteBandwidth;
				double writeCmpDataTime_ft = rSize_ft/diskWriteBandwidth;
				
				double totalOriTime = readDataTime + oriNetworkTransferTime + writeOriDataTime;
				double totalCmpTime = readDataTime + compressionTime + cmpNetWorkTransferTime + writeCmpDataTime;
				double totalCmpTime_ft = readDataTime + compressionTime_ft + cmpNetWorkTransferTime_ft + writeCmpDataTime_ft;
				
				//System.out.println(totalOriTime/86400+" < "+totalCmpTime/86400+" "+(totalCmpTime/totalOriTime)+" >,< "+totalCmpTime_ft/86400+" "+(totalCmpTime_ft/totalOriTime)+" >");
				System.out.println(totalOriTime/86400+" "+totalCmpTime/86400+" "+totalCmpTime_ft/86400);
				System.out.println("\t"+readDataTime+" "+oriNetworkTransferTime+" "+writeOriDataTime);
				System.out.println("\t"+readDataTime+" "+compressionTime+" "+cmpNetWorkTransferTime+" "+writeCmpDataTime);
			}	
		}
	}
}
